document.getElementById ("year").textContent = new Date();

let year = document.querySelector("#year");
year.textContent = new Date().getFullYear();


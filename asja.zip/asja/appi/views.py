from django.shortcuts import render
from.models import *

# Create your views here.
def home(request):
    books=Book.objects.all()
    context = {"books":books}
    categories=Category.objects.all()
    return render(request,"home.html",context)
def contact(request):
    if request.method == "POST":
        first_name = request.POST["firstName"]
        last_name = request.POST["lastName"]
        email_name = request.POST["email"]
        comment_name = request.POST["koment"]
        Contact(contact_name = first_name,
        contact_surname= last_name,
        contact_email= email_name,
        contact_comment=comment_name).save()
    return render(request,"contact.html")
def detail(request,id):
    detailBook= Book.objects.get(pk = id)
    context={"detailBook":detailBook}
    return render(request,"detail.html",context)
def register(request):
    return render(request,"register.html")
def category (request,id):
    categoryBook= Book.objects.get(pk = id)
    context={ "categoryBook":categoryBook}
    return render(request,"category.html",context)
